import { Component, OnInit } from '@angular/core';
import { Phone, IAlert } from '../model/Phone';
import { CustomerHomeService } from '../customer-home/customer-home.service';
import { Router } from '@angular/router';
import { AuthService } from '../security/auth.service';
import { CommonModule } from '@angular/common';  
import { BrowserModule } from '@angular/platform-browser';
import { CompareService } from '../compare/compare.service';

@Component({
  selector: 'app-show-phone',
  templateUrl: './show-phone.component.html',
 
  styleUrls: ['./show-phone.component.css'],

})
export class ShowPhoneComponent implements OnInit {  

 

  selectphone:boolean=false;
  selectphone1:boolean=false;
  selectphone2:boolean=false;
  name :string="";
  name1 :string="";
  isDesc: boolean = false;
  column: string = 'pName';
  direction: number;
  selectedRow : Number;
  setClickedRow : Function;
  selectedRow1 : Number;
  setClickedRow1 : Function;
  selectedRow2 : Number;
  setClickedRow2 : Function;
  headMessage : string;

  phone:Phone[];
  phone1:Phone[];
 public data:Phone[];
 public initialSort:Phone;
 public  pageSettings: Phone;
 visibleRrowIndex: number = null;
 public show:boolean = false;
 public buttonName:any = 'Show';
 customerval:String="none";
 addtocartlist:Phone[];
  cartItemCount: number = 0;
  alerts:Array<IAlert> = [];
  selectphn:any;
  selectphn1:any;
  selectphn2:any;
  obj: string;
  errorMessage:string;
  flag:boolean=true;
  flag1:boolean=false;
  selectedHero: Phone;

 
 
  selectedBoat:Phone;
  
  base={}
  onClickMe(p) { 
    const myObjStr = JSON.stringify(p);
    console.log(myObjStr); 
    this.selectphn=p;
    
   this.selectphone=true;
  }
  onClickMe1(d) { 
    const myObjStr = JSON.stringify(d);
    console.log(myObjStr); 
    this.selectphn1=d;
    
   this.selectphone1=true;
  }
  onClickMe2(p) { 
    const myObjStr = JSON.stringify(p);
    console.log(myObjStr); 
    this.selectphn2=p;
    
   this.selectphone2=true;
  }
  seller = Object.create(this.base);
  constructor( private ser:CustomerHomeService, private router:Router,private auth:AuthService,private ad:CompareService) { this.setClickedRow = function(index)
    {
    this.selectedRow = index;
  }
  this.setClickedRow1 = function(index){
    this.selectedRow1 = index;
}
this.setClickedRow2 = function(index){
  this.selectedRow2 = index;
}
}
user:string;
  ngOnInit():void {
    this.user=sessionStorage.getItem("user")
    this.ser.getallPhones()
    .then(
     (phone) => {
       this.phone = phone
      }
    )
    .catch(
      (error) => {
         this.errorMessage = error.message;
       }
    );
    this.ser.getallPhones1()
    .then(
     (phone1) => {
       this.phone1 = phone1
      }
    )
    .catch(
      (error) => {
         this.errorMessage = error.message;
       }
    );
   
    
    

  }
 
 
//   sort(property){
//     this.isDesc = !this.isDesc; //change the direction    
//     this.column = property;
//     let direction = this.isDesc ? 1 : -1;

//     this.phone.sort(function(a, b){
//         if(a[property] < b[property]){
//             return -1 * direction;
//         }
//         else if( a[property] > b[property]){
//             return 1 * direction;
//         }
//         else{
//             return 0;
//         }
//     });
// };
sort(property){
  this.isDesc = !this.isDesc; //change the direction    
  this.column = property;
  this.direction = this.isDesc ? 1 : -1;
}

edit(phone){
this.phone=phone.price;
}
addtocart(Phone)
  {
      console.log(Phone)
      this.addtocartlist=this.ser.getProductFromCart();
      if(this.addtocartlist==null)
      {
        //console.log(product);
        this.addtocartlist=[];
        this.addtocartlist.push(Phone);
        this.ser.addProductToCart(this.addtocartlist);
        this.alerts.push({
          id: 1,
          type: 'success',
          message: 'Product added to cart.'
        });
        setTimeout(()=>{   
          this.closeAlert(this.alerts);
     }, 3000);
  
      }
      else
      {
        console.log(this.addtocartlist.find(p=>p.phoneId==Phone.phoneId));
        let tempProduct=this.addtocartlist.find(p=>p.phoneId==Phone.productId);
        if(tempProduct==null)
        {
          console.log(Phone);
          this.addtocartlist.push(Phone);
          this.ser.addProductToCart(this.addtocartlist);
          this.alerts.push({
            id: 1,
            type: 'success',
            message: 'Product added to cart.'
          });
          //setTimeout(function(){ }, 2000);
          setTimeout(()=>{   
            this.closeAlert(this.alerts);
       }, 3000);
        }
        else
        {
          this.alerts.push({
            id: 2,
            type: 'warning',
            message: 'Product already exist in cart.'
          });
          setTimeout(()=>{   
            this.closeAlert(this.alerts);
       }, 3000);
        }
        
      }
     console.log(this.cartItemCount);
      this.cartItemCount=this.addtocartlist.length;
      // this.cartEvent.emit(this.cartItemCount);
       this.ad.updateCartCount(this.cartItemCount);
    }

    public closeAlert(alert:any) {
      const index: number = this.alerts.indexOf(alert);
      this.alerts.splice(index, 1);
    }


    productDesc(Phone){

      this.router.navigate(['productdesc'],{queryParams:{ source : JSON.stringify(Phone) },skipLocationChange:true })
    }
    copyMessage(Phone){
      let selBox = document.createElement('textarea');
      selBox.style.position = 'fixed';
      selBox.style.left = '0';
      selBox.style.top = '0';
      selBox.style.opacity = '0';
      selBox.value = Phone;
      document.body.appendChild(selBox);
      selBox.focus();
      selBox.select();
      document.execCommand('copy');
      document.body.removeChild(selBox);
    }
    onSelect(hero: Phone): void {
      this.selectedHero = hero;
    }
}




