import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CustomerHomeService } from '../customer-home/customer-home.service';
import { SellerHomeService } from '../seller-home/seller-home.service';
import { AuthService } from '../security/auth.service';

@Component({
  selector: 'app-phone-display',
  templateUrl: './phone-display.component.html',
  styleUrls: ['./phone-display.component.css']
})
export class PhoneDisplayComponent implements OnInit {

  constructor(private fb:FormBuilder,private customerhome:CustomerHomeService,private sellerhome:SellerHomeService,private auth:AuthService) { }
  phone:any;
  Phone:FormGroup;
  err:string;
  err1:string;
  seller:any;
  Seller:FormGroup;
  user:string;

  ngOnInit() {
    this.user=sessionStorage.getItem("user")

    this.Phone=this.fb.group({
      "phoneId":[sessionStorage.getItem("ID")],
      
    })
    this.customerhome.displayphone(this.Phone.value)
    .then(res => {
          this.phone=res;
        })
      .catch(err=>{
          this.err=err;
        }),
        this.Seller=this.fb.group({
          "sellerId":[sessionStorage.getItem("SID")],
          
        })
        this.sellerhome.displayseller(this.Seller.value)
        .then(res => {
              this.seller=res;
            })
          .catch(err1=>{
              this.err1=err1;
            })



  }

}
