import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import 'rxjs/add/operator/switchMap';
 
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppRoutingModule, routes } from './app-routing.module';
 
import { CommonModule } from '@angular/common';
import { HttpModule } from "@angular/http";
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { SellerHomeComponent } from './seller-home/seller-home.component';
import { RegisterComponent } from './register/register.component';
import { AddNewPhoneComponent } from './add-new-phone/add-new-phone.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { DeletePhoneComponent } from './delete-phone/delete-phone.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { SellerregisterService } from './register/sellerregister.service';
import { CustomerregisterService } from './register/Customerregister.service';
import { CustomerloginService } from './login/Customerlogin.service';
import { SellerloginService } from './login/sellerlogin.service';
import { AddphoneService } from './add-new-phone/Addphone.service';
import { CustomerHomeService } from './customer-home/customer-home.service';
import { PhoneDisplayComponent } from './phone-display/phone-display.component';
import { SellerHomeService } from './seller-home/seller-home.service';
import { AuthGuard } from './security/auth.guard';
import { AuthService } from './security/auth.service';
import { RouterModule } from '../../node_modules/@angular/router';
import { ShowPhoneComponent } from './show-phone/show-phone.component';
import { CategoryPipe } from './category.pipe';
import { OrderrByPipe } from './orderby.pipe';
import { CategoryPipe1 } from './category1.pipe';
import { CompareComponent } from './compare/compare.component';
import { CompareService } from './compare/compare.service';





@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    CustomerHomeComponent,
    SellerHomeComponent,
    RegisterComponent,
    AddNewPhoneComponent,
    UpdateDetailsComponent,
    DeletePhoneComponent,
    AboutUsComponent,
   
    PhoneDisplayComponent,
    
    ShowPhoneComponent,
    CategoryPipe,
    CategoryPipe1,
    OrderrByPipe,
    CompareComponent
    
  ],
  imports: [
   BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    FormsModule,
    HttpModule, CommonModule,
  ],
  providers: [CustomerregisterService,CustomerloginService,SellerregisterService,SellerloginService,AddphoneService,CustomerHomeService,SellerHomeService,AuthGuard,AuthService,CompareService],
  bootstrap: [AppComponent]
})
export class AppModule { }
  