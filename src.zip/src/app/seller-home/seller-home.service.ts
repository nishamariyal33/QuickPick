import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { AuthService } from '../security/auth.service';

@Injectable()
export class SellerHomeService {
  
  private key1:string;
  constructor(private http:Http,private auth:AuthService) { }

  public setKey(name : string) {
    this.key1 = name;
    sessionStorage.setItem("SID",this.key1);
    }

    
 

  displayseller(data):Promise<any>{
   //console.log(data);
    return this.http.post('http://localhost:7385/Mobile/MobilesAPI/getSellerDetails', data)
      .toPromise()
      .then(response => response.json())
      .catch(error => Promise.reject(error.json() || error));
  }
  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.message || error);
    }
}
