import { Component, OnInit } from '@angular/core';
import { AuthService } from '../security/auth.service';

@Component({
  selector: 'app-seller-home',
  templateUrl: './seller-home.component.html',
  styleUrls: ['./seller-home.component.css']
})
export class SellerHomeComponent implements OnInit {

  constructor(private auth:AuthService) { }
  suser:string;
  ngOnInit() {
    this.suser=sessionStorage.getItem("suser")
  }

}
