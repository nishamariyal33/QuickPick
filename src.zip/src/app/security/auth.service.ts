import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export class AuthService {
  sho: boolean=false;
  adminLoginFlag: boolean = true;

  constructor(private router:Router) { }
  sendToken(token: string) {
    sessionStorage.setItem("LoggedInUser", token)
  }
  getToken() {
    return sessionStorage.getItem("LoggedInUser")
  }
  isLoggednIn() {
    return this.getToken() !== null;
  }
  logout() {
   
    if (confirm('Do you really want to exit?')){
      sessionStorage.removeItem("LoggedInUser");
    this.router.navigate(["./"]); 
     
   }else{
    this.router.navigateByUrl(this.router.url);
   }
   
  }
  openNav() {
    this.sho=true;
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  closeNav() {
    this.sho=false;
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
  }

  checkAdmin():boolean{
    if(sessionStorage.getItem('username')=='shru1@gmail.com'){
      return false;
    }
    return true;
  }


}

