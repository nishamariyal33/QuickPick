import { Component, OnInit } from '@angular/core';
import { CustomerHomeService } from '../customer-home/customer-home.service';
import { Router } from '@angular/router';
import { SellerHomeService } from '../seller-home/seller-home.service';
import { AuthService } from '../security/auth.service';
import { Phone, IAlert } from '../model/Phone';
import { CompareService } from './compare.service';

@Component({
  selector: 'app-compare',
  templateUrl: './compare.component.html',
  styleUrls: ['./compare.component.css']
})
export class CompareComponent implements OnInit {
  addtocartlist:Phone[];
  cartItemCount: number = 0;
  alerts:Array<IAlert> = [];
  prod : Phone[];
  prod1:Phone[];
  obj: string;
  errorMessage:string;
  flag:boolean=true;
  flag1:boolean=false;
  productAddedTocart:Phone[];

  constructor(private customerhome:CustomerHomeService,private router:Router,private sellerhome:SellerHomeService,private auth:AuthService, private ad:CompareService) {  }
 
  fun(num:any){
    this.flag=false
    this.flag1=true;
    console.log(num)
    this.customerhome.getallPhones().then(response=>this.prod1=response)
  }
   
  fun1(){
    this.customerhome.getallPhones()
      .then(res => {this.prod = res
        this.flag=true;
        this.flag1=false;
      console.log(this.prod)})
       .catch(error => {this.errorMessage = error.message; });
    }
  
  ngOnInit() {
    this.obj=(sessionStorage.getItem("obj"))
    this.productAddedTocart=this.customerhome.getProductFromCart();
  for(let i of this.productAddedTocart){
    
  }
  this.customerhome.removeAllProductFromCart();
  this.customerhome.addProductToCart(this.productAddedTocart);
  
  // console.log(this.allTotal)
  }
  onAddQuantity(pro:Phone)
  {
    //Get Product

   

    //Find produc for which we want to update the quantity
    //let tempProd= this.productAddedTocart.find(p=>p.Id==product.Id);  
    //tempProd.Quantity=tempProd.Quantity+1;
   
    //this.productAddedTocart=this.productAddedTocart.splice(this.productAddedTocart.indexOf(product), 1)
   //Push the product for cart
   // this.productAddedTocart.push(tempProd);
  this.customerhome.removeAllProductFromCart();
  this.customerhome.addProductToCart(this.productAddedTocart);
  
  }
  onRemoveQuantity(product:Phone)
  {
    
    this.customerhome.removeAllProductFromCart();
    this.customerhome.addProductToCart(this.productAddedTocart);
   
  
}
  
  remove(prod:Phone){

    this.productAddedTocart=this.productAddedTocart.filter((cart)=>cart.phoneId!=prod.phoneId);
    this.customerhome.addProductToCart(this.productAddedTocart);
    
    }
    
  submit(){
    
    setTimeout(()=>{   
      this.closeAlert(this.alerts);
 }, 3000);

  }
  public closeAlert(alert:any) {
    const index: number = this.alerts.indexOf(alert);
    this.alerts.splice(index, 1);
  }

}
