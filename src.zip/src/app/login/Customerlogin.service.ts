import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
@Injectable()
export class CustomerloginService {

  constructor(private http: Http) { }

  login(data) :Promise<any>{
    return this.http.post('http://localhost:7385/Mobile/MobilesAPI/login', data)
      .toPromise()
      .then(response => response.json())
      .catch(error => Promise.reject(error.json() || error));
  }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }
  adlogin(data) :Promise<any>{
    return this.http.post('http://localhost:7385/Mobile/MobilesAPI/sellerlogin', data)
      .toPromise()
      .then(response => response.json())
      .catch(error => Promise.reject(error.json() || error));
  }
  private herrorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }
  getDetails(data) :Promise<any>{
    return this.http.post('http://localhost:7385/Mobile/MobilesAPI/getPhoneDetails', data)
      .toPromise()
      .then(response => response.json())
      .catch(error => Promise.reject(error.json() || error));
  }
  private hherrorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }

 
}  


