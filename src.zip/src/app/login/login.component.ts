import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerloginService } from './Customerlogin.service';
import { Router } from '@angular/router';
import { SellerloginService } from './sellerlogin.service';
import { AuthGuard } from '../security/auth.guard';
import { AuthService } from '../security/auth.service';
 
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  username:String;
  password:String;
  sellerName:String;
  spassword:String;
  successMessage:any;
  errorMessage:any;


  customerLoginForm:FormGroup;
  sellerLoginForm:FormGroup;
  show_button:boolean=false;
 show_eye:boolean=false;

  constructor(private fb: FormBuilder,private customerloginService:CustomerloginService,private router:Router,private sellerloginService: SellerloginService,private auth:AuthService) {  
     
  }

  login() {
    this.successMessage = null;
    this.errorMessage = null;
    this.customerloginService.login(this.customerLoginForm.value)
      .then(response => {
         this.router.navigateByUrl('/login/customerHome');
        this.successMessage = response.message;
        sessionStorage.setItem("user",this.customerLoginForm.controls.username.value)
         this.auth.sendToken(this.customerLoginForm.value);

      })
      .catch(error => {        
        this.errorMessage = error.message;
        
      })
    }
    adlogin() {
      this.successMessage = null;
      this.errorMessage = null;
      this.customerloginService.adlogin(this.sellerLoginForm.value)
        .then(response => {
           this.router.navigateByUrl('/login/seller');
          this.successMessage = response.message;
          sessionStorage.setItem("suser",this.sellerLoginForm.controls.sellerName.value)
          this.auth.sendToken(this.sellerLoginForm.value)
        })
        .catch(error => {        
          this.errorMessage = error.message;
        })
    }

  ngOnInit() { 
    if(this.auth.isLoggednIn()){
    
      this.router.navigate(['/login/customerHome']);
      
    } 
     
 
 
    this.customerLoginForm=this.fb.group({ 

      username:  ['', Validators.required],
      password:  ['', Validators.required]

    })

    this.sellerLoginForm=this.fb.group({ 

      sellerName:  ['', Validators.required],
      spassword:  ['', Validators.required]

    })
  }

  // sellerFormSubmit(){
  //   console.log("SellerLogin")

  // }

  // customerFormSubmit(){ 
  //   console.log("Customer Log")

  // }
  showPassword(){
    this.show_button=!this.show_button;
    this.show_eye=!this.show_eye;
  }

}
