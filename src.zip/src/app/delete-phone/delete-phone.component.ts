import { Component, OnInit } from '@angular/core';
import { Http } from '../../../node_modules/@angular/http';
import { AuthService } from '../security/auth.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AddphoneService } from '../add-new-phone/Addphone.service';

@Component({
  selector: 'app-delete-phone',
  templateUrl: './delete-phone.component.html',
  styleUrls: ['./delete-phone.component.css']
})
export class DeletePhoneComponent implements OnInit {
  deletePhoneForm:FormGroup;
  successMessage:any;
  errorMessage:any;

  //phone Table
  phoneId:number;
  pName:String;
  

  constructor( private fb: FormBuilder,private deletephoneService:AddphoneService,private auth:AuthService) { }
  deletephone() {
    this.successMessage = null;
    this.errorMessage = null;
    this.deletephoneService.deletephone(this.deletePhoneForm.value)
      .then(response => {
        // this.router.navigateByUrl('/mainpage');
        this.successMessage = response.message;
      })
      .catch(error => {        
        this.errorMessage = error.message;
      })
  } 

  suser:string;
  ngOnInit() {
    this.suser=sessionStorage.getItem("suser")
    this.deletePhoneForm=this.fb.group({ 
      phoneId: ['', Validators.required],
      modelNumber: ['', Validators.required]
    })

  }

}
