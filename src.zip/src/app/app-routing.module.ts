import { NgModule, ComponentFactory } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {RegisterComponent} from './register/register.component'
import {LoginComponent} from './login/login.component' 
import {HomeComponent } from './home/home.component' ;
import {SellerHomeComponent} from './seller-home/seller-home.component'
 import {CustomerHomeComponent} from  './customer-home/customer-home.component'
 import {AddNewPhoneComponent} from './add-new-phone/add-new-phone.component' 
 import {DeletePhoneComponent} from './delete-phone/delete-phone.component' 
 import {UpdateDetailsComponent} from './update-details/update-details.component'
 import { AboutUsComponent} from './about-us/about-us.component'
import { PhoneDisplayComponent } from './phone-display/phone-display.component';
import { AuthGuard } from './security/auth.guard';
import { ShowPhoneComponent } from './show-phone/show-phone.component';
import { CompareComponent } from './compare/compare.component';

//add the route object inside the below variables
export const routes: Routes = [

  
  {path: '',component:HomeComponent},

  {path:'login/seller/addPhone',component:AddNewPhoneComponent,canActivate:[AuthGuard]}, 
 {path:'login/seller/delete' ,component:DeletePhoneComponent,canActivate:[AuthGuard]},
  {path:'login/customerHome' ,component:CustomerHomeComponent,canActivate:[AuthGuard]}, 
  {path:'login/seller/update',component :UpdateDetailsComponent,canActivate:[AuthGuard]},
 
 {path:'login/seller' ,component:SellerHomeComponent,canActivate:[AuthGuard]},
  { path:'register', component: RegisterComponent },
  {path:'login' ,component: LoginComponent},
  {path:'aboutus',component: AboutUsComponent},
  {path:'displayphone',component:PhoneDisplayComponent,canActivate:[AuthGuard]},
  {path:'login/compare',component:ShowPhoneComponent,canActivate:[AuthGuard]},
  {path:'login/compare1',component:CompareComponent,canActivate:[AuthGuard]}
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
