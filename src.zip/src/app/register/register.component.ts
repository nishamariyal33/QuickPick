import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { SellerregisterService } from './sellerregister.service';
import { Router } from '@angular/router';
import { CustomerregisterService } from './Customerregister.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})


export class RegisterComponent implements OnInit { 


  customerval:String="none";
  sellerval:String="none"
//Form Groups
  sellerForm:FormGroup;
  customerForm:FormGroup;
  successMessage:any;
  errorMessage:any;

 //customer Table Entities  
customerId:number;
firstName:String;
lastName:String;
username:String;
password:String;
emailAddress:string;
state:String;
country:String;




//SELLER TABLE  COMPONENT  


sellerId:String;
sellerName:String;
spassword:String;
gender :String;
age:number;
emailId:String;
phoneNo:number;





  constructor(private fb: FormBuilder,private sellerregisterService:SellerregisterService, private router:Router,private customerregisterService:CustomerregisterService) { }

  signupseller() {
    this.successMessage = null;
    this.errorMessage = null;
    this.sellerregisterService.signupseller(this.sellerForm.value)
      .then(response => {
         this.router.navigateByUrl('/login');
        this.successMessage = response.message;
      })
      .catch(error => {        
        this.errorMessage = error.message;
      })
  }
  signupcustomer() {
    this.successMessage = null;
    this.errorMessage = null;
    this.customerregisterService.signupcustomer(this.customerForm.value)
      .then(response => {
        this.router.navigateByUrl('/login');
        this.successMessage = response.message;
      })
      .catch(error => {        
        this.errorMessage = error.message;
      })
  }
  customer(){ 
    console.log("CLICK CLICK")
    this.sellerval="none";

    this.customerval="customer";
  }
  seller(){ 
    console.log("Seller")
    this.sellerval="seller";
    this.customerval="none";
  }

  ngOnInit() { 





    //customer form builder
    this.customerForm=this.fb.group({ 
      
     
      firstName:  ['', [Validators.required,Validators.pattern("[a-zA-Z]+")]],
      lastName:  ['', [Validators.required,Validators.pattern("[a-zA-Z]+")]],
      username:  ['', [Validators.required,Validators.pattern("[a-zA-Z0-9]+")]],
      password:  ['', [Validators.required,Validators.minLength(8)]],
      emailAddress:  ['', [Validators.required,Validators.pattern("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+[.](com|in|org)")]],
      state:  ['',[Validators.required,Validators.pattern("[a-zA-Z]+")]],
      country:  ['',[Validators.required,Validators.pattern("[a-zA-Z]+")]]
    })



    //seller Form Builder 
  this.sellerForm=this.fb.group({ 
    sellerId: ['', [Validators.required,Validators.pattern("[S|s][a-zA-Z0-9]+")]],
    sellerName: ['', [Validators.required,Validators.pattern("[a-zA-Z0-9]+")]],
    spassword : ['', [Validators.required,Validators.minLength(8)]],
    gender: ['', [Validators.required]],
    age: ['', [Validators.required,Validators.min(18)]],
    emailId: ['',[Validators.required,Validators.pattern("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+[.](com|in|org)")]],
    phoneNo: ['', [Validators.required,Validators.pattern("[0-9]{10}")]],


  })




  }

}
