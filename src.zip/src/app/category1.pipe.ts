import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'category1' })
export class CategoryPipe1 implements PipeTransform {
  transform(categories1: any, searchText1: any): any {
    if(searchText1 == null) return categories1;

    return categories1.filter(function(category1){
      return category1.pName.toLowerCase().indexOf(searchText1.toLowerCase()) > -1;
    })
  }
} 