import { Seller } from "./Seller";

export class Phone{
     phoneId:number;
	 pName:string;
	 modelNumber:string;
	 brand:string;
    cameraResolution:number;
	 ram:number;
	memory:number;
	batteryCapacity:string;
    price:number;
    seller:Seller[];
     source:string;
     message:string;
	
}
export class IAlert {
    id: number;
    type: string;
    message: string;
}