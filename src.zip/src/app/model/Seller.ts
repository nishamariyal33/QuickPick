export class Seller{
    
	emailId:string;
	sellerName:string;
	age:number;
	phoneNo:number;
	sellerId:string;
	 gender:string;
	 spassword:string;
	message:string;

}