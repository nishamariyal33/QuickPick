import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { AuthService } from '../security/auth.service';
import { Phone } from '../model/Phone';

@Injectable()
export class CustomerHomeService {
  
  private key:string;
  constructor(private http:Http,private auth:AuthService) { }

  public setKey(name : string) {
    this.key = name;
    sessionStorage.setItem("ID",this.key);
    }

    
 

  displayphone(data):Promise<any>{
   //console.log(data);
    return this.http.post('http://localhost:7385/Mobile/MobilesAPI/getPhoneDetails', data)
      .toPromise()
      .then(response => response.json())
      .catch(error => Promise.reject(error.json() || error));
  }
  private errorHandler(error:any):Promise<any> {
    console.error("Error occured",error);    
    return Promise.reject(error.message || error);
    }
    getallPhones()
    {
      return this.http.get('http://localhost:7385/Mobile/MobilesAPI/getSellerPhones').
      toPromise().
      then(res=>res.json() as Phone[]).
      catch(this.errorHandler)
  
  
    }
    getallPhones1()
    {
      return this.http.get('http://localhost:7385/Mobile/MobilesAPI/getSellerPhones').
      toPromise().
      then(res=>res.json() as Phone[]).
      catch(this.errorHandler)
  
  
    }

    addProductToCart(prodcuts: any) {
      localStorage.setItem("product", JSON.stringify(prodcuts));
    }
    getProductFromCart() {
      //return localStorage.getItem("product");
      return JSON.parse(localStorage.getItem('Phone'));
    }
    removeAllProductFromCart() {
      return localStorage.removeItem("Phone");
    }
  
    handleError(error){
      return Promise.reject(error.json() || error);
    }
   
    
}
