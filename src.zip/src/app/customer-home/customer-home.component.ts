import { Component, OnInit } from '@angular/core';
import { CustomerHomeService } from './customer-home.service';
import { Router } from '@angular/router';
import { SellerHomeService } from '../seller-home/seller-home.service';
import { AuthService } from '../security/auth.service';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.css']
})
export class CustomerHomeComponent implements OnInit {

  constructor(private customerhome:CustomerHomeService,private router:Router,private sellerhome:SellerHomeService,private auth:AuthService) { }
  user:string;
  ngOnInit() {
    this.user=sessionStorage.getItem("user")

  }
  phoneDisplay(key:string,key1:string){
    this.customerhome.setKey(key);
    this.sellerhome.setKey(key1);
    this.router.navigateByUrl('/displayphone');
      }

} 
