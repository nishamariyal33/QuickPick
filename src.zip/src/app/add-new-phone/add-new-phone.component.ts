import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { StringifyOptions } from 'querystring';
import { AddphoneService } from './Addphone.service';
import { AuthService } from '../security/auth.service';
 
@Component({
  selector: 'app-add-new-phone',
  templateUrl: './add-new-phone.component.html',
  styleUrls: ['./add-new-phone.component.css']
})
export class AddNewPhoneComponent implements OnInit {
  addPhoneForm:FormGroup;
  featuresForm:FormGroup;
  successMessage:any;
  errorMessage:any;

  //phone Table
  phoneId:number;
  pName:String;
  modelNumber:String;
  brand:String;
  cameraResolution:number;
  ram:number;
  memory:number;
  batteryCapacity:number; 
  price:number;
 
   


  //FEATURES 
  
  osVersion:string;
  microphone:String;
  simSlots:String;
  headphone:String;
  noiseCanceling:String;
  flash:String;
  screenresolution:String;
  screenSize:String;
  maemoryCardSlot:String;
  bluethoot:String;
  network:String;
  suser:string;
 
  constructor(private fb: FormBuilder,private addphoneService:AddphoneService,private auth:AuthService) { }
  addphone() {
    this.successMessage = null;
    this.errorMessage = null;
    this.addphoneService.addphone(this.addPhoneForm.value)
      .then(response => {
        // this.router.navigateByUrl('/mainpage');
        this.successMessage = response.message;
      })
      .catch(error => {        
        this.errorMessage = error.message;
      })
  } 


  ngOnInit() { 
    this.suser=sessionStorage.getItem("suser")

    //add phone form Builder
    this.addPhoneForm=this.fb.group({ 
      
      pName: ['', Validators.required],
      modelNumber: ['', Validators.required],
      brand: ['', Validators.required],
      cameraResolution: ['', Validators.required],
      ram: ['', [Validators.required,Validators.max(12)]],
      memory: ['', Validators.required],
      batteryCapacity: ['', [Validators.required,Validators.min(1000)]],
      price: ['', Validators.required],
      source: ['', Validators.required],
      phon: ['', [Validators.required,Validators.pattern("[0-9]{10}")]],
      email:  ['',[Validators.required,Validators.pattern("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+[.](com|in|org)")]]
      // sellerId:this.fb.group({sellerId:['', Validators.required]}) 
    })

    // this.featuresForm=this.fb.group({ 
    //   ram: [''],
    //   frontCamera: [''],
    //   rearCamera: [''],
    //   memory: [''],
    //   osVersion: [''],
    //   microphone: [''],
    //   simSlots: [''],
    //   headphone: [''],
    //   noiseCanceling: [''],
    //   flash: [''],
    //   screenresolution: [''],
    //   screenSize: [''],
    //   maemoryCardSlot: [''],
    //   bluethoot: [''],
    //   network: ['']

    // })


  }
  onFileChanged(event) {
    const file = event.target.files[0]
  }

}
