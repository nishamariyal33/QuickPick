import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { AuthService } from '../security/auth.service';
@Injectable()
export class AddphoneService {

  constructor(private http: Http,private auth:AuthService) { }

  addphone(data) :Promise<any>{
    console.log("data")
    return this.http.post('http://localhost:7385/Mobile/MobilesAPI/addPhone', data)    
      .toPromise()
      .then(response => response.json())
      .catch(error => Promise.reject(error.json() || error));
  }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }
  updatephone(data) :Promise<any>{
    console.log("data")
    return this.http.post('http://localhost:7385/Mobile/MobilesAPI/updatePhones', data)    
      .toPromise()
      .then(response => response.json())
      .catch(error => Promise.reject(error.json() || error));
  }
  deletephone(data) :Promise<any>{
    console.log("data")
    return this.http.post('http://localhost:7385/Mobile/MobilesAPI/deletePhones', data)    
      .toPromise()
      .then(response => response.json())
      .catch(error => Promise.reject(error.json() || error));
  }
  private herrorHandler(error:any):Promise<any> {
  console.error("Error occured",error);    
  return Promise.reject(error.message || error);
  }

}  


