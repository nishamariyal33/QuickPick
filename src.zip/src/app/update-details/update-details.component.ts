import { Component, OnInit } from '@angular/core';
import { AuthService } from '../security/auth.service';
import { CustomerloginService } from '../login/Customerlogin.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AddphoneService } from '../add-new-phone/Addphone.service';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {
  userDetails: any;
  errorMessage:any;
  successMessage:any;
  user:String="none";
  customerval:String="none";
  sellerval:String="none";
  updatePhoneForm:FormGroup;


  //phone Table
  phoneId:number;
  pName:String;
  modelNumber:String;
  brand:String;
  cameraResolution:number;
  ram:number;
  memory:number;
  batteryCapacity:number; 
  price:number;
  
 

  constructor(private fb: FormBuilder, private updatephoneService:AddphoneService,private auth:AuthService,private cust:CustomerloginService) { }
  suser:string;
  customer(){ 
    console.log("CLICK CLICK")
    this.sellerval="none";

    this.customerval="customer";
  }
  seller(){ 
    console.log("Seller")
    this.sellerval="seller";
    this.customerval="none";
  }
  updatephone() {
    this.successMessage = null;
    this.errorMessage = null;
    this.updatephoneService.updatephone(this.updatePhoneForm.value)
      .then(response => {
        // this.router.navigateByUrl('/mainpage');
        this.successMessage = response.message;
      })
      .catch(error => {        
        this.errorMessage = error.message;
      })
  } 


  ngOnInit() {
    this.suser=sessionStorage.getItem("suser")
    this.updatePhoneForm=this.fb.group({ 
      phoneId: ['', Validators.required],
     
      modelNumber: ['', Validators.required],
    
      cameraResolution: ['',[Validators.required,Validators.pattern("[0-9]+")]],
      ram: ['',[Validators.required,Validators.pattern("[0-9]+")]],
      memory: ['',[Validators.required,Validators.pattern("[0-9]+")]],
      batteryCapacity: ['',[Validators.required,Validators.pattern("[0-9]+")]],
      price: ['', [Validators.required,Validators.pattern("[0-9]+")]],
      phon: ['', [Validators.required,Validators.pattern("[0-9]{10}")]],
      source:['', Validators.required],
      email: ['',[Validators.required,Validators.pattern("[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+[.](com|in|org)")]]

      // sellerId:this.fb.group({sellerId:['', Validators.required]}) 
    })

  }
  getUserDetails=this.fb.group({
    "phoneId":["",[Validators.required]]
  })
  getDetails(){
    this.errorMessage = null
    this.successMessage = null
    this.userDetails= null
    this.cust.getDetails(this.getUserDetails.value)
    .then(user => {
      this.userDetails = user;
      
    }).catch(error => {
      this.errorMessage = error.message
    })
  }
}
