package com.mobile.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;







import com.mobile.dao.MobileComparisonDAO;
import com.mobile.entity.CustomerEntity;
import com.mobile.entity.PhoneEntity;
import com.mobile.entity.SellerEntity;
import com.mobile.model.Customer;
import com.mobile.model.Phone;
import com.mobile.model.Seller;

@Service(value = "MobileComparisonService")
@Transactional(readOnly=true)
public class MobileComparisonServiceImpl implements  MobileComparisonService{

	@Autowired
	private MobileComparisonDAO dao;
	@Transactional(readOnly=false, propagation  = Propagation.REQUIRES_NEW)
	public Customer register(Customer customer) throws Exception{
	     
		List<CustomerEntity> finall=dao.getCustomerDetails(customer);
		Customer register=null;
		if(finall==null){
		 register=dao.register(customer);
			
		}
		else{
			throw new Exception("Register.invalid");
		}
		return register;
		}
	

	public Customer login(Customer customer) throws Exception{
		Customer user1= dao.login(customer);
		if(user1==null)
		{
			throw new Exception("Login.Invalid");
		}
		return user1;
		
	}
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public Seller register(Seller seller) throws Exception {
		List<SellerEntity> finall=dao.getUsername(seller);
		Seller register=null;
		if(finall==null){
		 register=dao.register(seller);
			
		}
		else{
			throw new Exception("Register.invalid");
		}
		return register;
		}
	

	@Override
	
	public Seller adLogin(Seller adminLogin) throws Exception {
		Seller s=dao.adLogin(adminLogin);
		if(s==null)
		{
			throw new Exception("Login.Invalid");
		}

		return s;

		
	}
		
	@Override
	@Transactional(readOnly=false, propagation  = Propagation.REQUIRES_NEW)
	public Phone addPhone(Phone phone) throws Exception{
	     
		List<PhoneEntity> finall=dao.getPhoneDetails(phone);
		Phone register=null;
		if(finall==null){
		 register=dao.addPhone(phone);
			
		}
		else{
			throw new Exception("Add.Invalid");
		}
		return register;
		}
	
	
	@Override
	@Transactional(readOnly = true)
	public Phone getPhoneByPhoneId(Integer phoneId)
			throws Exception {

		Phone phone  = null;
		phone = dao.getPhoneByPhoneId(phoneId);
		if (phone == null) {
			throw new Exception("SERVICE.PHONE_NOT_FOUND");
		}
		return phone;
	}
	@Override
	@Transactional(readOnly = true)
	public Seller getSellerBySellerId(String sellerId)
			throws Exception {

		Seller seller  = null;
		seller = dao.getSellerBySellerId(sellerId);
		if (seller == null) {
			throw new Exception("SELLER.SELLER_NOT_FOUND");
		}
		return seller;
	}
	@Override
	public List<Phone> getallPhones() throws Exception {
		
		return dao.getallPhones();
	}
	@Transactional(readOnly = false,propagation=Propagation.REQUIRES_NEW)
	@Override
	public Phone updatePhone(Phone phone) throws Exception {
		
		List<PhoneEntity> finall=dao.getPhoneDetails(phone);
		Phone register=null;
		if(finall!=null){
		 register=dao.updatePhone(phone);
		 return register;
			
		}
		else{
			throw new Exception("SERVICE.PHONE_NOT_FOUND");
		}
		
		}
	
	public Phone deletePhone(Phone phone) throws Exception{

		List<PhoneEntity> finall=dao.getPhoneDetails(phone);
		Phone p=null;
		if(finall!=null)
		 
		{	p=dao.deletePhone(phone);
		    return p;
		}
		
		else
			throw new Exception("SERVICE.PHONE_NOT_FOUND");
		
		
	
	}
}

