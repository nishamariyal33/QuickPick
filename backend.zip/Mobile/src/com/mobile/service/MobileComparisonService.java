package com.mobile.service;













import java.util.List;

import com.mobile.model.Customer;
import com.mobile.model.Phone;
import com.mobile.model.Seller;

public interface MobileComparisonService {

public Customer register(Customer customer) throws Exception; 
	
public Customer login(Customer customer) throws Exception;
public Seller register(Seller seller) throws Exception;

public Seller adLogin(Seller adminLogin) throws Exception;

public Phone getPhoneByPhoneId(Integer phoneId) throws Exception;


Phone addPhone(Phone phone) throws Exception;

Seller getSellerBySellerId(String sellerId) throws Exception;



List<Phone> getallPhones() throws Exception;

Phone updatePhone(Phone phone) throws Exception;

public Phone deletePhone(Phone phone) throws Exception;




}
