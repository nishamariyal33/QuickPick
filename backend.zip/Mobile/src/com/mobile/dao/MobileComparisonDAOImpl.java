package com.mobile.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;











import com.mobile.entity.CustomerEntity;
import com.mobile.entity.PhoneEntity;
import com.mobile.entity.SellerEntity;
import com.mobile.model.Customer;
import com.mobile.model.Phone;
import com.mobile.model.Seller;


@Repository(value="dao") 
public class MobileComparisonDAOImpl implements MobileComparisonDAO {

	@Autowired
	SessionFactory sessionFactory;
public Customer register (Customer customer) throws Exception{
		
	Session session = sessionFactory.getCurrentSession();

	CustomerEntity customerEntity = new CustomerEntity(customer);
	
	Integer id = (Integer) session.save(customerEntity);

	customer.setCustomerId(id);

	return customer;
	}


	public Customer login(Customer customer) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> criteriaQuery=builder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(
				builder.and(
				builder.equal(root.get("username"),customer.getUsername()),
				builder.equal(root.get("password"),customer.getPassword())
				));
		
		Query<CustomerEntity> query = session.createQuery(criteriaQuery);
		CustomerEntity cu=query.uniqueResult();
		if(cu==null){
			throw new Exception("Login.Invalid");
		}
		Customer c=new Customer(cu);
		return c;
	}
	
	
	@Override
	public List<CustomerEntity> getCustomerDetails(Customer customer) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<CustomerEntity> criteriaQuery=builder.createQuery(CustomerEntity.class);
		Root<CustomerEntity> root = criteriaQuery.from(CustomerEntity.class);
		criteriaQuery.where(
				builder.equal(root.get("username"),customer.getUsername())
				);
		criteriaQuery.select(root.get("username"));
		Query<CustomerEntity> query = session.createQuery(criteriaQuery);
		List<CustomerEntity> list = query.getResultList();
		if(list!=null && !list.isEmpty()) {
			return list;
		}
		else{
			return null;
		}
	}	


	@Override
	public Seller register(Seller seller) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();

		SellerEntity sellerEntity = new SellerEntity(seller);
		
		String id = (String) session.save(sellerEntity);

		seller.setSellerId(id);

		return seller;
	}

	@Override
	public List<SellerEntity> getUsername(Seller seller) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<SellerEntity> criteriaQuery=builder.createQuery(SellerEntity.class);
		Root<SellerEntity> root = criteriaQuery.from(SellerEntity.class);
		criteriaQuery.where(
				builder.equal(root.get("sellerName"),seller.getSellerName())
				);
		criteriaQuery.select(root.get("sellerName"));
		Query<SellerEntity> query = session.createQuery(criteriaQuery);
		List<SellerEntity> list = query.getResultList();
		if(list!=null && !list.isEmpty()) {
			return list;
		}
		else{
			return null;
		}
	}


	@Override
	public Seller adLogin(Seller adminLogin) throws Exception {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder=session.getCriteriaBuilder();
		CriteriaQuery<SellerEntity> criteriaQuery=builder.createQuery(SellerEntity.class);
		Root<SellerEntity> root=criteriaQuery.from(SellerEntity.class);
		criteriaQuery.select(root);
		criteriaQuery.where(
				builder.and(
						builder.equal(root.get("sellerName"), adminLogin.getSellerName()),
						builder.equal(root.get("spassword"), adminLogin.getSpassword())));
		
		Query<SellerEntity> query= session.createQuery(criteriaQuery);
		SellerEntity ce=query.uniqueResult();
		if(ce==null){
			
			throw new Exception("Login.Invalid");
		}
		Seller c=new Seller(ce);
		
		return c;
		
	}
			
		
		
	
	

	@Override
	public Phone addPhone (Phone phone) throws Exception{
		
		Session session = sessionFactory.getCurrentSession();

		PhoneEntity phoneEntity = new PhoneEntity(phone);
		
		Integer id = (Integer) session.save(phoneEntity);

		phone.setPhoneId(id);;

		return phone;
		}
	
	@Override
	public List<PhoneEntity> getPhoneDetails(Phone phone) throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PhoneEntity> criteriaQuery=builder.createQuery(PhoneEntity.class);
		Root<PhoneEntity> root = criteriaQuery.from(PhoneEntity.class);
		criteriaQuery.where(
				builder.equal(root.get("modelNumber"),phone.getModelNumber())
				);
		criteriaQuery.select(root.get("modelNumber"));
		Query<PhoneEntity> query = session.createQuery(criteriaQuery);
		List<PhoneEntity> list = query.getResultList();
		if(list!=null && !list.isEmpty()) {
			return list;
		}
		else{
			return null;
		}
	}


	@Override
	public Phone getPhoneByPhoneId(Integer phoneId) {
		// TODO Auto-generated method stub
		
	              
	              Session session = sessionFactory.getCurrentSession();
	              PhoneEntity phoneEntity = session.get( PhoneEntity.class, phoneId);
	              if(    phoneEntity!=null) {
	                     Phone phone = new Phone(phoneEntity);
	                     
	                     return phone;
	              }
	              return null;
	              
	       

		
	}	
	public Seller getSellerBySellerId(String sellerId) {
		// TODO Auto-generated method stub
		
	              
	              Session session = sessionFactory.getCurrentSession();
	              SellerEntity sellerEntity = session.get( SellerEntity.class, sellerId);
	              if(    sellerEntity!=null) {
	                     Seller seller = new Seller(sellerEntity);
	                     
	                     return seller;
	              }
	              return null;
	              
	       

		
	}
	
	
	
	
	@Override
	public List<Phone> getallPhones() throws Exception {
		
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<PhoneEntity> criteriaQuery= builder.createQuery(PhoneEntity.class);
		
		Root<PhoneEntity> root = criteriaQuery.from(PhoneEntity.class);
		criteriaQuery.select(root);
		
		List<Phone> le=new ArrayList<>();
		List<PhoneEntity> ee=session.createQuery(criteriaQuery).getResultList();
		
		for (PhoneEntity phoneEntity : ee) {
			
			Phone e=new Phone(phoneEntity);
			le.add(e);
		}
		
		return le;
		
	}
	@Override
	public Phone updatePhone(Phone phone) throws Exception {
		
		
		Session session = sessionFactory.getCurrentSession();
		PhoneEntity ee=session.get(PhoneEntity.class,phone.getPhoneId());
		if(ee!=null)
		{
	
		ee.setPrice(phone.getPrice());
		ee.setRam(phone.getRam());
		ee.setMemory(phone.getMemory());
		ee.setCameraResolution(phone.getCameraResolution());
		ee.setBatteryCapacity(phone.getBatteryCapacity());
		ee.setEmail(phone.getEmail());
		ee.setPhon(phone.getPhon());
		ee.setSource(phone.getSource());
		session.save(ee);
		return new Phone(ee);
		}
		else
			throw new Exception();
	
		
}
	public Phone deletePhone(Phone p) throws Exception{
		Session session =  sessionFactory.getCurrentSession();
		PhoneEntity pe=session.get(PhoneEntity.class,p.getPhoneId());
		
if(pe!=null)
	  {pe.setSeller(null);
	  session.delete(pe);
	  session.flush();   
		return p;}
else
	throw new Exception();
		
			
	}
	
	
	
}