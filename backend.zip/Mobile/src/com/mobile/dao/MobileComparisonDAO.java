package com.mobile.dao;

import java.util.List;

import com.mobile.entity.CustomerEntity;
import com.mobile.entity.PhoneEntity;
import com.mobile.entity.SellerEntity;
import com.mobile.model.Customer;
import com.mobile.model.Phone;
import com.mobile.model.Seller;



public interface MobileComparisonDAO {
	
   public Customer register(Customer customer) throws Exception;
   
   public Customer login(Customer customer) throws Exception;
   public Seller register (Seller seller) throws Exception;
   public Seller adLogin(Seller adminLogin) throws Exception;

    
    List<CustomerEntity> getCustomerDetails(Customer customer) throws Exception;
    List<SellerEntity> getUsername(Seller seller) throws Exception;
    Phone addPhone(Phone phone) throws Exception;

	List<PhoneEntity> getPhoneDetails(Phone phone) throws Exception;

	public Phone getPhoneByPhoneId(Integer phoneId);
	public Seller getSellerBySellerId(String sellerId);

	
	List<Phone> getallPhones() throws Exception;

	Phone updatePhone(Phone phone) throws Exception;
	
	public Phone deletePhone(Phone phone) throws Exception;


}
