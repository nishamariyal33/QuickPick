package com.mobile.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.Table;


import com.mobile.model.Seller;

@Entity
@Table(name="SELLER")
public class SellerEntity {

	@Id
	private String sellerId;
	
	
	private String gender;
	@Column(name="password")
	private String spassword;
	@Column(name="adminName")
	private String sellerName;
	private Integer age;
	private String emailId;
	private Long phoneNo;
	
	 
	public SellerEntity(){
		
	}
	
	
	


	public String getSellerId() {
		return sellerId;
	}





	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}





	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	





	public String getSpassword() {
		return spassword;
	}





	public void setSpassword(String spassword) {
		this.spassword = spassword;
	}





	public String getSellerName() {
		return sellerName;
	}





	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}





	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public SellerEntity(Seller cbe)
	{
		this.setSellerName(cbe.getSellerName());
		this.setAge(cbe.getAge());
		this.setEmailId(cbe.getEmailId());
		this.setGender(cbe.getGender());
		
		this.setSpassword(cbe.getSpassword());
		this.setPhoneNo(cbe.getPhoneNo());
		this.setSellerId(cbe.getSellerId());
	}

}
