package com.mobile.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.mobile.model.Phone;


@Entity
@Table(name="PHONE")
@GenericGenerator(name="kaugen" , strategy="increment")
public class PhoneEntity {
	@Id
	@GeneratedValue(generator="kaugen")
	@Column(name="PHONEID")
	private Integer phoneId;
	
	private String pName;
	private String modelNumber;
	private String brand;
	private Integer cameraResolution;
	private Integer ram;
	private Integer memory;
	private Integer batteryCapacity;
	private Integer price;
	private String source;
	private String email;
	private String phon;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhon() {
		return phon;
	}
	public void setPhon(String phon) {
		this.phon = phon;
	}
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "SELLERSID", unique = true)
	private SellerEntity seller;
	public Integer getPhoneId() {
		return phoneId;
	}
	public void setPhoneId(Integer phoneId) {
		this.phoneId = phoneId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getModelNumber() {
		return modelNumber;
	}
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public Integer getCameraResolution() {
		return cameraResolution;
	}
	public void setCameraResolution(Integer cameraResolution) {
		this.cameraResolution = cameraResolution;
	}
	public Integer getRam() {
		return ram;
	}
	public void setRam(Integer ram) {
		this.ram = ram;
	}
	public Integer getMemory() {
		return memory;
	}
	public void setMemory(Integer memory) {
		this.memory = memory;
	}
	public Integer getBatteryCapacity() {
		return batteryCapacity;
	}
	public void setBatteryCapacity(Integer batteryCapacity) {
		this.batteryCapacity = batteryCapacity;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public SellerEntity getSeller() {
		return seller;
	}
	public void setSeller(SellerEntity seller) {
		this.seller = seller;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public PhoneEntity(){
		
	}
	public PhoneEntity(Phone cbe)
	{
		this.setPhoneId(cbe.getPhoneId());
		this.setpName(cbe.getpName());
		this.setModelNumber(cbe.getModelNumber());
		this.setBrand(cbe.getBrand());
		this.setCameraResolution(cbe.getCameraResolution());
		this.setRam(cbe.getRam());
		this.setMemory(cbe.getMemory());
		this.setPrice(cbe.getPrice());
		
		this.setSeller(cbe.getSeller());
		this.setBatteryCapacity(cbe.getBatteryCapacity());
		this.setSource(cbe.getSource());
		this.setEmail(cbe.getEmail());
		this.setPhon(cbe.getPhon());
	
		
	}
}
