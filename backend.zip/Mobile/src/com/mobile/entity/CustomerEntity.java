package com.mobile.entity;




import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;





import org.hibernate.annotations.GenericGenerator;

import com.mobile.model.Customer;

@Entity
@Table(name="CUSTOMER")
@GenericGenerator(name="kaugen" , strategy="increment")
public class CustomerEntity {

	@Id  
	@GeneratedValue(generator="kaugen")
	
    private Integer customerId;
	private String firstName;
	private String lastName;
	private String username;
	private String password;
	private String emailAddress;
	private String state;
	private String country;
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public CustomerEntity() {
		
	}
	public CustomerEntity(Customer se) {
		this.setCustomerId(se.getCustomerId());
		this.setFirstName(se.getFirstName());
		this.setLastName(se.getLastName());
		this.setUsername(se.getUsername());
		this.setPassword(se.getPassword());
		this.setEmailAddress(se.getEmailAddress());
		this.setState(se.getState());
		this.setCountry(se.getCountry());
		
	}
	
}
