DROP TABLE CUSTOMER;

Drop table PHONE;
Drop table SELLER;


CREATE TABLE CUSTOMER(  

CUSTOMERID NUMBER(4) CONSTRAINT CUSTID PRIMARY KEY,

FIRSTNAME VARCHAR(50) NOT NULL,

LASTNAME VARCHAR(50) NOT NULL,

USERNAME VARCHAR(20) NOT NULL,

PASSWORD VARCHAR(30) NOT NULL,

EMAILADDRESS VARCHAR(20) NOT NULL,

STATE VARCHAR(50),

COUNTRY VARCHAR(50) NOT NULL);


INSERT INTO CUSTOMER values(1001,'Nish','Mary','nishu123','infy@123','nish@gmail.com','tamilnadu','india');

INSERT INTO CUSTOMER values(1002,'Vedavyas','Thirunagiri','veda44','infy@123','vedvyas@gmail.com','Andhra Pradesh','India');

INSERT INTO CUSTOMER values(1003,'Kishore','Harry','kish03','infy@123','kish@gmail.com','Kerala','India');






CREATE table SELLER(
    
   
    emailId VARCHAR2(50) ,
    adminName VARCHAR2(25) unique,
    SELLERID VARCHAR2(5) not null ,
    phoneNo NUMBER(10) ,
    password VARCHAR2(50) ,
    gender VARCHAR2(6)  ,
    age NUMBER(2) ,
    
    CONSTRAINT SID PRIMARY KEY(SELLERID)
   
  );

INSERT INTO SELLER VALUES ('nisha@gmail.com','nisha08','S101',9911253531,'infy@123','F',21);
INSERT INTO SELLER VALUES ('vedavyas@gmail.com','vedavyas04','S102',9511253532,'infy@123','M',21);
INSERT INTO SELLER VALUES ('karthi@gmail.com','karthi08','S103',9411253533,'infy@123','M',22);
INSERT INTO SELLER VALUES ('subham@gmail.com','subham01','S104',9611253534,'infy@123','M',24);
INSERT INTO SELLER VALUES ('deepak@gmail.com','deepak08','S105',9911253535,'infy@123','M',22);
INSERT INTO SELLER VALUES ('devansh02@gmail.com','devansh02','S106',9511253536,'infy@123','M',23);
INSERT INTO SELLER VALUES ('prachi08@gmail.com','prachi08','S107',9411253537,'infy@123','F',28);
INSERT INTO SELLER VALUES ('nancy@gmail.com','nancy08','S108',9611253538,'infy@123','F',22);
INSERT INTO SELLER VALUES ('john@gmail.com','john08','S109',9911253539,'infy@123','M',22);
INSERT INTO SELLER VALUES ('radhika@gmail.com','radhi04','S110',9511253530,'infy@123','F',26);

INSERT INTO SELLER VALUES ('aarohi@gmail.com','aarohi08','S111',9411253510,'infy@123','F',20);
INSERT INTO SELLER VALUES ('krish@gmail.com','krish01','S112',9611253512,'infy@123','M',33);
INSERT INTO SELLER VALUES ('amitha@gmail.com','amitha08','S113',9911253511,'infy@123','F',24);
INSERT INTO SELLER VALUES ('kishore@gmail.com','kish04','S114',9511253513,'infy@123','M',22);
INSERT INTO SELLER VALUES ('kiran@gmail.com','kiran08','S115',9411253514,'infy@123','M',40);
INSERT INTO SELLER VALUES ('dany@gmail.com','dany01','S116',9611253515,'infy@123','F',23);
INSERT INTO SELLER VALUES ('harry@gmail.com','harry08','S117',9911253516,'infy@123','M',29);
INSERT INTO SELLER VALUES ('voldemort@gmail.com','voldy02','S118',9511253517,'infy@123','M',22);
INSERT INTO SELLER VALUES ('cersei@gmail.com','cersei01','S119',9411253518,'infy@123','F',34);
INSERT INTO SELLER VALUES ('bellatrix@gmail.com','bella08','S120',9611253519,'infy@123','F',25);
INSERT INTO SELLER VALUES ('hermoine@gmail.com','hermie08','S121',9911253520,'infy@123','F',24);
INSERT INTO SELLER VALUES ('christy@gmail.com','christy04','S122',9511253521,'infy@123','F',22);
INSERT INTO SELLER VALUES ('mahesh@gmail.com','mahesh08','S123',9411253522,'infy@123','M',25);
INSERT INTO SELLER VALUES ('christopher@gmail.com','christo01','S124',9611253523,'infy@123','M',32);

SELECT * from SELLER;



CREATE TABLE PHONE(  


PHONEID NUMBER(5) CONSTRAINT PID PRIMARY KEY,
PNAME VARCHAR(50)NOT NULL,
MODELNUMBER VARCHAR(50) NOT NULL unique,
BRAND VARCHAR(50) NOT NULL,
CAMERARESOLUTION NUMBER(15) NOT NULL,
RAM NUMBER(2) NOT NULL,
BATTERYCAPACITY NUMBER(15) NOT NULL,
PRICE number(10) NOT NULL,
MEMORY NUMBER(3) NOT NULL,
SELLERSID VARCHAR(5),
source varchar2(50),
phon varchar2(20),
email VARCHAR2(50),
CONSTRAINT SELLER_P FOREIGN KEY (SELLERSID) REFERENCES SELLER(SELLERID)
);



INSERT INTO PHONE values(10001,'Samsung Galaxy S10 plus','SM-S101245','samsung',12,8,4100,73900,128,'S101','/assets/image2.jpg','9911253531','nisha@gmail.com');
INSERT INTO PHONE values(10002,'Mi A2','Mi-A100275','mi',12,6,3010,15999,128,'S102','/assets/sr3.jpg','9511253532','vedavyas@gmail.com');
INSERT INTO PHONE values(10003,'Honor 8x','H-X2012','honor',20 ,6,3750,18999,128,'S103','/assets/honor8xx.jpg','9411253533','karthi@gmail.com');
INSERT INTO PHONE values(10004,'iphone x','I-X82012','apple',12,3,2716,83400,256,'S104','/assets/iphonexx.png','9611253534','subham@gmail.com');
INSERT INTO PHONE values(10005,'Mi A1','Mi-A200275','mi',12 ,4,3080,11999,64,'S105','/assets/MiA11.jpeg','9911253535','deepak@gmail.com');

INSERT INTO PHONE values(10006,'Honor  9 lite','H-L92012','honor',13 ,4,3000,17999,64,'S106','/assets/h9.jpg','9511253536','devansh02@gmail.com');
INSERT INTO PHONE values(10007,'Samsung Galaxy S9 plus','SM-S72012','samsung',12 ,6,3500,63900,128,'S107','/assets/s92.jpg','9411253537','prachi08@gmail.com');
INSERT INTO PHONE values(10008,'Redmi Note7 Pro','Mi-N72012','mi',48 ,4,4000,13999,64,'S108','/assets/x1.jpg','9611253538','nancy@gmail.com');
INSERT INTO PHONE values(10009,'Nokia 8.1 plus','N-62012','nokia',16 ,6,3700,34990,128,'S109','/assets/nokia1.jpg','9911253539','john@gmail.com');
INSERT INTO PHONE values(10010,'Samsung Galaxy Note 9','SM-N92012','samsung',12 ,6,4000,67900,128,'S110','/assets/note99.jpg','9511253530','radhika@gmail.com');


INSERT INTO PHONE values(10011,'Huawei P30 Pro','HW-HP2012','Huawei',40 ,8,4200,71990,256,'S111','/assets/huaweip300.jpg','9411253510','aarohi@gmail.com');
INSERT INTO PHONE values(10012, 'ONE PLUS 6T', 'OP-6T2012', 'oneplus', 16, 8, 3700,32999,128, 'S112', '/assets/onep.jpg','9611253512','krish@gmail.com');

INSERT INTO PHONE values(10013, 'ONE PLUS 6', 'OP-62018', 'oneplus', 16, 8, 3300,28999,128, 'S113', '/assets/oneplus.png','9911253511','amitha@gmail.com');

INSERT INTO PHONE values(10014, 'SAMSUNG GALAXY M30', 'SM-M305FZBDINS', 'samsung', 16, 4, 5000, 14999, 64, 'S114', '/assets/galaxym30.jpg','9511253513','kishore@gmail.com');

INSERT INTO PHONE values(10015, 'Realme 3 Pro', 'RMX 1851', 'realme', 16, 4, 4045, 15999, 64, 'S115', '/assets/realme3pro.jpeg','9411253514','kiran@gmail.com');

INSERT INTO PHONE values(10016, 'OPPO F11 Pro', 'CPH1969', 'oppo', 48, 6, 4000, 24990, 64, 'S116', '/assets/OPPOF11Pro.jpg','9611253515','dany@gmail.com');

INSERT INTO PHONE values(10017, 'Motorola One', 'Moto One Power P30', 'motorola', 16, 4, 5000, 13464, 64, 'S117', '/assets/moto.jpg','9911253516','harry@gmail.com');

INSERT INTO PHONE values(10018, 'Apple iPhone XS Max', 'A1921', 'apple', 12, 4, 3174, 99900, 64, 'S118', '/assets/iphone-xs-max.png','9511253517','voldemort@gmail.com');

INSERT INTO PHONE values(10019, 'Microsoft Lumia 650', 'Lumia 650', 'microsoft', 8, 1, 2000, 11999, 16, 'S119', '/assets/MicrosoftLumia.jpg','9411253518','cersei@gmail.com');

INSERT INTO PHONE values(10020, 'Micromax Bharat Go', 'Q437', 'micromax', 5, 1, 2000, 4399, 8, 'S120', '/assets/micromax.jpg','9611253519','bellatrix@gmail.com');







INSERT INTO PHONE values(10021, 'HTC U12 plus', 'HTC U12+', 'htc', 16, 6, 3500, 76990, 64, 'S121', '/assets/htc.jpg','9911253520','hermoine@gmail.com');

INSERT INTO PHONE values(10022, 'BlackBerry Key2 LE', 'BBE100-4', 'blackBerry', 13, 4, 3000, 28989, 64, 'S122', '/assets/BLACKBERRY.jpg','9511253521','christy@gmail.com');

INSERT INTO PHONE values(10023, 'Sony Xperia XZ2', 'Xperia-XZ2', 'sony', 19, 6, 3180, 57900, 64, 'S123', '/assets/sonyxperiaXZ2.jpg','9411253522','mahesh@gmail.com');

INSERT INTO PHONE values(10024, 'Google Pixel 3', 'Go13', 'google', 12, 4, 2915, 59699, 64, 'S124', '/assets/google.jpg','9611253523','christopher@gmail.com');


SELECT * from PHONE;
