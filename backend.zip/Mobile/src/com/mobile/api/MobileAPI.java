package com.mobile.api;


import java.util.ArrayList;
import java.util.List;




import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;














import com.mobile.model.Customer;
import com.mobile.model.Phone;
import com.mobile.model.Seller;
import com.mobile.service.MobileComparisonServiceImpl;
import com.mobile.utility.ContextFactory;


@CrossOrigin
@RestController
@RequestMapping(value="MobilesAPI")
public class MobileAPI {

	
private MobileComparisonServiceImpl service;
	
	@RequestMapping(value="register" , method=RequestMethod.POST)
	public ResponseEntity<Customer> register(@RequestBody Customer customer){
		Environment environment= ContextFactory.getContext().getEnvironment();
		service= ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
		Customer user1=new Customer();
		ResponseEntity<Customer> responseEntity =null;
		try{
		  user1 = service.register(customer);
		  String message = environment.getProperty("Registration.Successful") + customer.getCustomerId();
			user1.setMessage(message);
			responseEntity = new ResponseEntity<Customer> (user1, HttpStatus.OK);
		}catch(Exception e){
			String errorMessage = environment.getProperty(e.getMessage());
			Customer user2=new Customer();
			user2.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Customer>(user2,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@RequestMapping(value="login" , method=RequestMethod.POST)
	public ResponseEntity<Customer> login(@RequestBody Customer customer){
		Environment environment= ContextFactory.getContext().getEnvironment();
		service= ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
		
		ResponseEntity<Customer> responseEntity=null;
		Customer user1 = new Customer();
		try{
			 user1 = service.login(customer);
			  String message = environment.getProperty("Login.Successful");
				user1.setMessage(message);
				responseEntity = new ResponseEntity<Customer> (user1, HttpStatus.OK);
		}catch(Exception e){
			user1.setMessage("Invalid Username or Password");
			responseEntity = new ResponseEntity<Customer> (user1, HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="sellerregister")
	public ResponseEntity<Seller> register(@RequestBody Seller seller) throws Exception{
		Environment environment= ContextFactory.getContext().getEnvironment();
		service=ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
		ResponseEntity<Seller> responseEntity=null;
		Seller returnSignup=new Seller();
		
		try{
			returnSignup=service.register(seller);
			String message = environment.getProperty("Registration.Successful") + seller.getSellerId();
			returnSignup.setMessage(message);
			responseEntity = new ResponseEntity<Seller>(returnSignup,HttpStatus.OK);
		}
		catch(Exception exception){
		//	exception.printStackTrace();
			String errorMessage = environment.getProperty(exception.getMessage());
			Seller returnSignup1=new Seller();
			returnSignup1.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Seller>(returnSignup1,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="sellerlogin")
	public ResponseEntity<Seller> bookConcert(@RequestBody Seller adminLogin) throws Exception {
		Environment environment=ContextFactory.getContext().getEnvironment();
		service=ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
		ResponseEntity<Seller> responseEntity=null;
		Seller cBooking=new Seller();
		try
		{
			cBooking=service.adLogin(adminLogin);
			String message=environment.getProperty("Login.Successful");
			cBooking.setMessage(message);
			responseEntity=new ResponseEntity<Seller>(cBooking,HttpStatus.OK);
		}
		catch(Exception e)
		{
			cBooking.setMessage("Invalid username or password");
			responseEntity=new ResponseEntity<Seller>(cBooking,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	
	
	@RequestMapping(method=RequestMethod.POST, value="getPhoneDetails")
    public ResponseEntity<Phone> getDetails(@RequestBody Phone phone){

           Environment environment= ContextFactory.getContext().getEnvironment();
           
           service = (MobileComparisonServiceImpl) ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
           
           ResponseEntity<Phone> responseEntity;
           try {
        	   Phone p= service.getPhoneByPhoneId(phone.getPhoneId());
        	   String message = environment.getProperty("PHONE.FETCHED_DETAILS") + phone.getPhoneId();
   			   p.setMessage(message);
        	   responseEntity = new ResponseEntity<Phone>(p,HttpStatus.OK);

           }
           
           catch(Exception e)
           {
        	String errorMessage = environment.getProperty(e.getMessage());
   			Phone p2=new Phone();
   			p2.setMessage(errorMessage);
   			responseEntity = new ResponseEntity<Phone>(p2,HttpStatus.BAD_REQUEST);
        	   
           }
      
           return responseEntity;
	
}
	
	
	@RequestMapping(method=RequestMethod.POST, value="getSellerDetails")
    public ResponseEntity<Seller> getDetails(@RequestBody Seller seller){

           Environment environment= ContextFactory.getContext().getEnvironment();
           
           service = (MobileComparisonServiceImpl) ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
           
           ResponseEntity<Seller> responseEntity;
           try {
        	   Seller p= service.getSellerBySellerId(seller.getSellerId());
        	   String message = environment.getProperty("SELLER.FETCHED_DETAILS") + seller.getSellerId();
   			   p.setMessage(message);
        	   responseEntity = new ResponseEntity<Seller>(p,HttpStatus.OK);

           }
           
           catch(Exception e)
           {
        	String errorMessage = environment.getProperty(e.getMessage());
   			Seller p2=new Seller();
   			p2.setMessage(errorMessage);
   			responseEntity = new ResponseEntity<Seller>(p2,HttpStatus.BAD_REQUEST);
        	   
           }
      
           return responseEntity;
	
}
	@RequestMapping(method=RequestMethod.GET, value="getSellerPhones")
	public ResponseEntity<List<Phone>> getallPhones(){
		Environment environment= ContextFactory.getContext().getEnvironment();
	{
		ResponseEntity<List<Phone>> res=null;
		List<Phone> emp=null;
		Phone phone=null;
		try{
			emp=service.getallPhones();
			res=new ResponseEntity<>(emp,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String error =environment.getProperty(e.getMessage());
			phone=new Phone();
			phone.setMessage(error);
			emp=new ArrayList<Phone>();
			emp.add(phone);
			res = new ResponseEntity<>(emp,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}}
	@RequestMapping(value="addPhone" , method=RequestMethod.POST)
	public ResponseEntity<Phone> addPhone(@RequestBody Phone phone){
		Environment environment= ContextFactory.getContext().getEnvironment();
		service= ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
		Phone user1=new Phone();
		ResponseEntity<Phone> responseEntity =null;
		try{
		  user1 = service.addPhone(phone);
		  String message = environment.getProperty("Add.Successful") + phone.getPhoneId();
			user1.setMessage(message);
			responseEntity = new ResponseEntity<Phone> (user1, HttpStatus.OK);
		}catch(Exception e){
			String errorMessage = environment.getProperty(e.getMessage());
			Phone user2=new Phone();
			user2.setMessage(errorMessage);
			responseEntity = new ResponseEntity<Phone>(user2,HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	@RequestMapping(method=RequestMethod.POST, value="updatePhones")
	public ResponseEntity<Phone> updatePhone(@RequestBody Phone phone)
	{
		Environment environment= ContextFactory.getContext().getEnvironment();
		service= ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
		ResponseEntity<Phone> res=null;
		Phone pho=new Phone();
		try{
			pho=service.updatePhone(phone);
			 String message = environment.getProperty("API.UPDATE_SUCCESSFUL") + phone.getPhoneId();
			 pho.setMessage(message);
			 res=new ResponseEntity<>(pho,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String errorm = environment.getProperty(e.getMessage());
			Phone p=new Phone();
			p.setMessage(errorm);
			res = new ResponseEntity<>(p,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	@RequestMapping(method=RequestMethod.POST, value="deletePhones")
	public ResponseEntity<Phone> deletePhone(@RequestBody Phone phone)
	{
		Environment environment= ContextFactory.getContext().getEnvironment();
		service= ContextFactory.getContext().getBean(MobileComparisonServiceImpl.class);
		ResponseEntity<Phone> res=null;
		Phone pho=new Phone();
		try{
			pho=service.deletePhone(phone);
			 String message = environment.getProperty("API.DELETE_SUCCESSFUL") ;
			 pho.setMessage(message);
			 res=new ResponseEntity<>(pho,HttpStatus.OK);
		}
		catch(Exception e)
		{
			String errorm = environment.getProperty(e.getMessage());
			Phone p=new Phone();
			p.setMessage(errorm);
			res = new ResponseEntity<>(p,HttpStatus.BAD_REQUEST);
			
		}
		return res;
		
	}
	
	

}
	



