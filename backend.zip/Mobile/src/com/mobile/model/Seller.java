package com.mobile.model;

import com.mobile.entity.SellerEntity;


public class Seller {

	
	private String emailId;
	private String sellerName;
	
	private Integer age;
	private Long phoneNo;
	private String sellerId;
	private String gender;
	private String spassword;
	private String message;
	
	
	public Seller()
	{
		
	}
	
	public String getSellerName() {
		return sellerName;
	}

	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getSpassword() {
		return spassword;
	}

	public void setSpassword(String spassword) {
		this.spassword = spassword;
	}

	public Seller(SellerEntity cbe)
	{
		this.setSellerName(cbe.getSellerName());
		this.setAge(cbe.getAge());
		this.setEmailId(cbe.getEmailId());
		this.setGender(cbe.getGender());
		
		this.setSpassword(cbe.getSpassword());
		this.setPhoneNo(cbe.getPhoneNo());
		this.setSellerId(cbe.getSellerId());
	}
	

}
