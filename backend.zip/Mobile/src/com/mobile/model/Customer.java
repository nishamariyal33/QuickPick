package com.mobile.model;




import com.mobile.entity.CustomerEntity;






public class Customer {

	
		private Integer customerId;
		private String firstName;
		private String lastName;
		private String username;
		private String password;
		private String emailAddress;
		private String state;
		private String country;
		private String message;
		
		public Integer getCustomerId() {
			return customerId;
		}
		public void setCustomerId(Integer customerId) {
			this.customerId = customerId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		
		
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getEmailAddress() {
			return emailAddress;
		}
		public void setEmailAddress(String emailAddress) {
			this.emailAddress = emailAddress;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public Customer(){
		}
		
		public Customer(CustomerEntity se) {
			this.setCustomerId(se.getCustomerId());
			this.setFirstName(se.getFirstName());
			this.setLastName(se.getLastName());
			this.setUsername(se.getUsername());
			this.setPassword(se.getPassword());
			this.setEmailAddress(se.getEmailAddress());
			this.setState(se.getState());
			this.setCountry(se.getCountry());
			
		}
		
		
}
